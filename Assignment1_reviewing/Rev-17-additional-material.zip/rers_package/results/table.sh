#!/bin/bash

#v1.0

AFL=0
KLEE=0
BOTH=0
TOTAL=0
T_AFL=0
T_KLEE=0
T_BOTH=0
T_TOTAL=0
rm -f temp_*

function usage_error {
    echo "ERROR: Usage"
    exit 1
}

if [ ! -z $1 ]; then
    case $1 in
    -o )
        if [ -z "$2" ]; then
            usage_error
        else
            rm -f $2
            OUTPUT=$2
        fi
    ;;
    esac
else
    rm -f all_result.txt
    OUTPUT=all_result.txt
fi

echo -e "#Problem,AFL,KLEE,BOTH,TOTAL,TWENTE,RESULT" >> $OUTPUT
echo -e "Problem\tAFL\tKLEE\tBOTH\tTOTAL\tTWENTE\tRESULT"

for f_afl in ./*afl*
do
  cat $f_afl | cut -d'_' -f2 | sort -n > temp_afl.txt
  f_klee="${f_afl/_afl_crashes.txt/_klee_crashes.txt}"
  cat $f_klee | cut -d'_' -f2 | sort -n > temp_klee.txt
  while read -r line; do
    check=$(cat temp_klee.txt | cut -d'_' -f2 | grep -w $line)
    if [ -z "$check" ]
  	then
  		AFL=$(($AFL + 1))
  	else
  		BOTH=$(($BOTH + 1))
  	fi
  done < temp_afl.txt
  KLEE=$(($(cat temp_klee.txt | wc -l) - $BOTH))
  NAME=$(echo $f_afl | cut -d'm' -f2 | cut -d'_' -f1)
  TOTAL=$(($AFL + $KLEE + $BOTH))
  SOLUTION=$(cat SOLUTION.txt | grep Problem_$NAME | cut -d',' -f2)
  TWENTE=$(cat TWENTE.txt | grep Problem_$NAME | cut -d',' -f2)
  if [ "$NAME" = "4" ] || [ "$NAME" = "5" ] || [ "$NAME" = "6" ];then
    SOLUTION="N.A."
    TWENTE="N.A."
  fi
  echo "Problem_$NAME,$AFL,$KLEE,$BOTH,$TOTAL,$TWENTE,$SOLUTION" >> $OUTPUT
  echo -e "Pr$NAME\t$AFL\t$KLEE\t$BOTH\t$TOTAL\t$TWENTE\t$SOLUTION"
  T_AFL=$(($T_AFL + $AFL))
  T_KLEE=$(($T_KLEE + $KLEE))
  T_BOTH=$(($T_BOTH + $BOTH))
  T_TOTAL=$(($T_TOTAL + $TOTAL))
  AFL=0
  KLEE=0
  BOTH=0
  TOTAL=0
  rm -f temp*
done

echo "Total,$T_AFL,$T_KLEE,$T_BOTH,$T_TOTAL,246,317" >> $OUTPUT
echo -e "Tot\t$T_AFL\t$T_KLEE\t$T_BOTH\t$T_TOTAL\t246\t317"
echo "---> Created file $OUTPUT"
