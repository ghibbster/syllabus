#!/bin/bash

RERS2016URL='http://www.rers-challenge.org/2016/problems/Reachability/'
RERS2016NAME='ReachabilityRERS2016.zip'
RERS2016URL+=$RERS2016NAME
RERS2016DIR='re2016'

RERS2017URL='http://rers-challenge.org/2017/problems/training/'
RERS2017NAME='RERS17TrainingReachability.zip'
RERS2017URL+=$RERS2017NAME
RERS2017DIR='re2017'

CONTAINER_NAME=klee_container

function retrieve_file {
        echo -n "Looking for $1... "
        if [ -e $1 ]
        then
                echo 'Found.'
        else
                echo 'Not found.'

                echo "Downloading $1..."
                if ! wget $2
                then
                        echo "Could not download $1."
                        exit 1
                fi
                echo "Downloaded $1."
        fi
}

function decompress_archive {
        echo -n "Looking for $2... "
        if [ -d $2 ]
        then
                echo 'Found.'
        else
                echo 'Not found.'

                echo "Decompressing $1"
                if ! unzip $1 -d $2
                then
                        echo "Could not decompress $1."
                        exit 1
                fi
                echo "Decompressed $1."
        fi
}

function cleanup_directory {
        DSSTORE='.DS_Store'
        MACOSDIR='__MACOSX'
        echo -n "Deleting unnecessary files from $1... "
        find $1 -name $DSSTORE -type f -delete
        find $1 -path "*/$MACOSDIR*" -delete
        find $1 -name '*.java' -delete
        echo 'Done.'
}

function prepare_folder {
        NAME=$(basename "$1")
        AFL_NAME=$NAME'_afl'
        echo -n "Preparing $1... "
        mkdir -p $1/afl_tests
        echo 1 > $1/afl_tests/1.txt
        mkdir -p $1/afl_findings
        if [ ! -e $1/$NAME.c ]
        then
                echo 'Failed.'
                echo "Cannot find $NAME.c"
                exit 1
        else
                cp "$1/$NAME.c" "$1/$NAME"'_afl.c'
                cp "$1/$NAME.c" "$1/$NAME"'_klee.c'
                cp res/minimize_tests.sh "$1"
                cp res/start_fuzzing.sh "$1"
                cp res/start_docker.sh "$1"
                cp res/start_concolic.sh "$1"
                cp res/view_crashes.sh "$1"
                cp res/view_crashes_klee.sh "$1"
                cp res/analyze_angr.py "$1"
        fi
        echo 'Done.'
}

retrieve_file $RERS2016NAME $RERS2016URL
retrieve_file $RERS2017NAME $RERS2017URL
decompress_archive $RERS2016NAME $RERS2016DIR
decompress_archive $RERS2017NAME $RERS2017DIR
cleanup_directory $RERS2016DIR
cleanup_directory $RERS2017DIR

PROBLEMS2016=$(find $RERS2016DIR -name 'Problem*' -type d)
PROBLEMS2017=$(find $RERS2017DIR -name 'Problem*' -type d)
PROBLEMS="$PROBLEMS2016 $PROBLEMS2017"

for PROBLEM in $PROBLEMS
do
        prepare_folder $PROBLEM
done

echo "Patching $RERS2016DIR for AFL..."
patch -p1 -l -d $RERS2016DIR < res/afl_2016.patch
echo "Patching $RERS2017DIR for AFL..."
patch -p1 -l -d $RERS2017DIR < res/afl_2017.patch
echo "Patching $RERS2016DIR for KLEE..."
patch -p1 -l -d $RERS2016DIR < res/klee_2016.patch
echo "Patching $RERS2017DIR for KLEE..."
patch -p1 -l -d $RERS2017DIR < res/klee_2017.patch

echo -n 'Looking for docker container... '
if [ ! "$(docker ps -a -q -f name=$CONTAINER_NAME)" ]
then
        echo 'Not found.'

        echo 'Creating docker container...'
        docker create -ti \
        	--name=$CONTAINER_NAME \
        	--ulimit='stack=-1:-1' \
        	-v $PWD:/home/klee/rers_assignment:z \
        	klee/klee
else
        echo 'Found.'
fi
