import argparse
import angr


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('binary', type=file)
    return parser.parse_args()


def get_function(proj, func_name):
    found_funcs = [func for addr, func in proj.kb.functions.iteritems()
                  if func_name == func.name]
    if len(found_funcs) > 0:
        return found_funcs[0]
    else:
        raise Exception('No verifier function found!')


def main():
    args = parse_arguments()

    print 'Opening angr project...',
    proj = angr.Project(args.binary.name)
    print 'Done.'

    print 'Getting target address...',
    proj.analyses.CFG()
    target_addr = max(get_function(proj, '__VERIFIER_error').block_addrs)
    print 'Done.'

    print 'Target address is {:#x}'.format(target_addr)

    print 'Starting to look for paths to target address...'
    with open('output_angr.txt', 'w') as f_out:
        path_group = proj.factory.path_group(threads=4)
        while (path_group.active) > 0:
            path_group.explore(find=target_addr)
            found = path_group.found[-1].state.posix.dumps(2)
            print 'New crash reached: {}'.format(found)
            f_out.write(found + '\n')
            f_out.flush()
    print 'No more active paths.'


if __name__ == '__main__':
    main()
