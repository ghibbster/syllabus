#!/bin/sh

DIRNAME=${PWD##*/}
if [[ ! $DIRNAME =~ Problem[0-9]+ ]]
then
        echo 'This script should be run in a Problem directory'
        exit 1
fi

echo -n "Looking for $DIRNAME AFL executable... "
if [ -e $DIRNAME ]
then
        echo 'Found.'
else
        echo 'Not found.'

        echo "Compiling $DIRNAME"'_afl.c...'
        afl-gcc -std=c99 -o $DIRNAME $DIRNAME'_afl.c'
fi

afl-fuzz -i afl_tests -o afl_findings -- ./$DIRNAME
