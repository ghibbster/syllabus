#!/bin/bash

DIRNAME=${PWD##*/}
if [[ ! $DIRNAME =~ Problem[0-9]+ ]]
then
        echo 'This script should be run in a Problem directory'
        exit 1
fi

OUTPUT_FILE=$DIRNAME'_afl_crashes.txt'

for FILE in minimized/*
do
        ./$DIRNAME < $FILE &>> $OUTPUT_FILE
done

ERRORS=$(grep -o 'error_[0-9]\+' $OUTPUT_FILE | sort -u)
echo $ERRORS > $OUTPUT_FILE
sed -i 's/ /\n/g' $OUTPUT_FILE
