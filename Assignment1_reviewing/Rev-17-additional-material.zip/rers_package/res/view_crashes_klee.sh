#!/bin/bash

#v1.0

DIRNAME=${PWD##*/}
if [[ ! $DIRNAME =~ Problem[0-9]+ ]]
then
        echo 'ERROR: This script should be run in a Problem directory'
        exit 1
fi

if [ ! $(whoami) == 'klee' ]
then
        echo 'ERROR: This script should be run from inside the docker image'
        exit 1
fi

OUTPUT_NAME=$DIRNAME'_klee_crashes.txt'

RUNNABLE=temp_"$DIRNAME".bc

export LD_LIBRARY_PATH=/home/klee/klee_build/klee/lib/:$LD_LIBRARY_PATH
clang -I /home/klee/klee_src/include -L /home/klee/klee_build/klee/lib "$DIRNAME"_klee.c -o $RUNNABLE -lkleeRuntest
for f in "$PWD"/klee-out-*/*.ktest
do
        KTEST_FILE=$f ./$RUNNABLE &>> temp_errors_klee.txt
done

grep -o 'error_[0-9]\+' temp_errors_klee.txt | sort -u >> $OUTPUT_NAME
sed -i 's/ /\n/g' $OUTPUT_NAME

rm -f temp*

echo "FINISHED!"
