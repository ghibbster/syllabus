#!/bin/sh

DIRNAME=${PWD##*/}
if [[ ! $DIRNAME =~ Problem[0-9]+ ]]
then
        echo 'This script should be run in a Problem directory'
        exit 1
fi

if [ ! -d minimized ]
then
        echo 'Creating minimized directory...'
        mkdir minimized
fi

echo 'Minimizing crashes...'

CRASHES=afl_findings/crashes/*

for f in $CRASHES
do
        m=`echo $f | grep -o 'id:[0-9]*'`
        if [ "$m" != "" ]
        then
                echo "Minimizing $f..."
                afl-tmin -i $f -o minimized/$m -- ./$DIRNAME 2> /dev/null
        fi
done

echo 'Eliminating duplicates...'

MINIMIZED=minimized/*

for m1 in $MINIMIZED
do
        for m2 in $MINIMIZED
        do
                if [ $m1 != $m2 ]
                then
                        if cmp -s "$m1" "$m2"
                        then
                                echo "Removing $m2..."
                                rm "$m2"
                        fi
                else
                        break
                fi
        done
done
