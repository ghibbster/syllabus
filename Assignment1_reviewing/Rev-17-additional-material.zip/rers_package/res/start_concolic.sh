#!/bin/bash

DIRNAME=${PWD##*/}
if [[ ! $DIRNAME =~ Problem[0-9]+ ]]
then
        echo 'This script should be run in a Problem directory'
        exit 1
fi

if [ ! $(whoami) == 'klee' ]
then
        echo 'This script should be run from inside the docker image'
        exit 1
fi

echo -n "Looking for $DIRNAME KLEE executable... "
if [ -e "$DIRNAME.bc" ]
then
        echo 'Found.'
else
        echo 'Not found.'

        echo "Compiling $DIRNAME"'_klee.c...'
        clang -I /home/klee/klee_src/include -emit-llvm -g -c \
                $DIRNAME'_klee.c' -o $DIRNAME.bc
fi

klee --only-output-states-covering-new --optimize --libc=uclibc \
        ./$DIRNAME.bc > /dev/null
