#!/bin/bash

DIRNAME=${PWD##*/}
if [[ ! $DIRNAME =~ Problem[0-9]+ ]]
then
        echo 'This script should be run in a Problem directory'
        exit 1
fi

CONTAINER_NAME=klee_container

if [ ! "$(docker ps -a -q -f name=$CONTAINER_NAME)" ]
then
        echo 'Docker container not found.'
        exit 1
fi

echo "docker start -ai $CONTAINER_NAME"
